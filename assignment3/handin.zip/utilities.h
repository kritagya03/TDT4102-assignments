#include "std_lib_facilities.h"
#pragma once

int randomWithLimits(int a, int b);