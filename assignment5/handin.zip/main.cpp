#include "std_lib_facilities.h"
#include "Card.h"
#include "CardDeck.h"

//1e) Mer organisert og ryddig

int main() {
    BlackJack b(0);
    b.playBlackJack();

    return 0;
}
